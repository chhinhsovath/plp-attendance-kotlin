const express = require('express');
const router = express.Router();

// Placeholder for notification routes
router.get('/', (req, res) => {
  res.json({ message: 'Notification routes - Coming soon' });
});

module.exports = router;
