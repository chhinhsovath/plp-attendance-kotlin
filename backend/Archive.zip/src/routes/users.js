const express = require('express');
const router = express.Router();

// Placeholder for user management routes
router.get('/', (req, res) => {
  res.json({ message: 'User routes - Coming soon' });
});

module.exports = router;
