const express = require('express');
const router = express.Router();

// Placeholder for school management routes
router.get('/', (req, res) => {
  res.json({ message: 'School management routes - Coming soon' });
});

module.exports = router;
